package javaarray;
//2D array
public class A3 {
	public static void main(String[] args) {
		int arr[][]= {{10,20,70},{50,60,45},{70,90,34}};
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(arr[i][j]+ " ");
			}System.out.println(" ");
		}
		
		
	}
}
