package oops;
//Simple object and class example
class car{
	String brand="Ferrai";
	String color="red";
	double price=900000;
	
	void display() {
		System.out.println(" Car info is:" +brand+ " "+color+ " "+price);
	}
}

public class O1 {
	public static void main(String[] args) {
		car obj=new car();
		//System.out.println(obj.brand);
		//System.out.println(obj.color);
		//System.out.println(obj.price);
		obj.display();
	}

}
