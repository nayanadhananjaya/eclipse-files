package javaabstract;
//abstract example
abstract class B{
	void display() {
		System.out.println("Message from display");
	}
	abstract void calculate();
	abstract void discount();
}

public class A2 extends B{
	void calculate() {
		System.out.println("msg from calculator");
	}
	void discount() {
		System.out.println("msg from discount");
	}
    public static void main(String[] args) {
    	A2 obj=new A2();
    	obj.display();
    	obj.calculate();
    	obj.discount();
    }
}
