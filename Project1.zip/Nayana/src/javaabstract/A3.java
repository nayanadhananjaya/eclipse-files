package javaabstract;
//abstract example
abstract class Shape{
	int l;
	int b;
	Shape(int l,int b){
		this.l=l;
		this.b=b;
	}
	abstract void area();
}

class Triangle extends Shape{
	Triangle(int l,int b){
		super(l,b);
	}
	void area() {
		double res;
		res=(l*b)*(0.5);
		System.out.println("Area of a traingle is " +res);
	}
}
class Rectangle extends Shape{
	Rectangle(int l,int b){
		super(l,b);	
	}
	void area() {
		float res;
		res=l*b;
		System.out.println("Area of rectangle is " +res);
	}
}
public class A3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle obj=new Triangle(20,30);
		obj.area();
		
		Rectangle obj1=new Rectangle(20,40);
		obj1.area();		
	}
}
