package wrapper;
//generic example
class A<T>{
	T i;
	A(T val){
		this.i=val;
	}
	T getobject() {
		return this.i;
	}
}
public class Ckeck2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A <Integer>obj=new A<Integer>(20);
		System.out.println(obj.getobject());
		
		A <String>obj1=new A<String>("john");
		System.out.println(obj1.getobject());
	}
}
