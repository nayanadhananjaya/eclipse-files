//Array display
public class Test2 {
	public static void main(String args[]) {
		int marks[]= {45,89,34,25,78,90};
		System.out.println(marks[5]);
		
		String name="Nayana";
		System.out.println("Name is :"+name);
		
	}

}
