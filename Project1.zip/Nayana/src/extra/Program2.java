package extra;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        InputStream ip=null;
        try {
			ip=new FileInputStream("C:\\Users\\user51\\eclipse-workspace\\Nayana\\src\\extra\\hello.txt");
			int i;
			while( (i=ip.read())!=-1) {
				System.out.println((char)i);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
        
	}

}
