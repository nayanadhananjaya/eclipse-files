package extra;
//json example and file writing example
import java.io.Writer;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;
public class Filewriter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="Welcome to my application";
		try {
			FileWriter fw=new FileWriter("C:\\Users\\user51\\eclipse-workspace\\Nayana\\src\\extra\\hello.txt");
			JSONObject obj=new JSONObject();
			JSONObject obj1=new JSONObject();
			obj.put("id",1);
	    	obj.put("name","Luffy");
			obj.put("age",22);
			obj1.put("id", 2);
			obj1.put("name","zoro");
			obj1.put("age", 23);
			fw.write(msg);
			fw.write(obj.toJSONString()+"\n"+ obj1.toJSONString());
			fw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
        System.out.println("done");
	}

}
