package extra;
//input stream reader
import java.io.IOException;
import java.io.InputStreamReader;
public class Program1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        InputStreamReader ip=null;
        ip=new InputStreamReader(System.in);
        System.out.println("Enter characters ,"+" '0' to quit");
        char c;
        do {
        	c=(char)ip.read();
        	System.out.println(c);
        }while(c!='0');
	}

}
