package javaexception;
class InvaldUserException extends Exception{
	public InvaldUserException(String msg) {
		super(msg);
	}
}

public class Customexception {
	static void validateuser(String username,String password)throws InvaldUserException{
		if(username.equals("admin")&& password.equals("admin123")) {
			System.out.println("User is valid");
		}else {
			throw new InvaldUserException("Invalid user");
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			validateuser("admin","admin1235");
		}catch(InvaldUserException e) {
			e.printStackTrace();
		}
	}
}
