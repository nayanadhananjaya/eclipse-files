package javaexception;
//nullpointerexception
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name=null;
		try {
			System.out.println(name.length());
		}catch(NullPointerException e) {
			//e.printStackTrace();
			//System.out.println(e.toString());
			System.out.println(e.getMessage());
		}
    }
}