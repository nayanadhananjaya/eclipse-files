package javaexception;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=20;
		String msg=null;
		int[] numbers= {10,20,30,40,50};
		try {
			System.out.println(numbers[5]);
			System.out.println(msg.length());
			System.out.println(num/0);
		}catch(NullPointerException e) {
			System.out.println("I am null");
			System.out.println(e);	
		}catch(ArithmeticException e) {
			System.out.println(num/(0+1));
		}catch(ArrayIndexOutOfBoundsException ex) {
			System.out.println("Exception occured is"+ex);
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}
