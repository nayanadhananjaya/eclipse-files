package javaexception;

public class Test9 {
	static void task() throws NullPointerException{
		System.out.println("With in task.");
		throw new NullPointerException("No value present");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			task();
			
		}catch(NullPointerException e) {
			System.out.println("caught in main " +e.getMessage());
		}

	}

}
