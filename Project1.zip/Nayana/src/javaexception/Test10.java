package javaexception;
import java.io.IOException;

class All{
	void display() throws IOException{
		System.out.println("Msg from display");
		throw new IOException("Input output error");
	}
}
public class Test10 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		All obj=new All();
		obj.display();

	}

}
