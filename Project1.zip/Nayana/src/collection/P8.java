package collection;
//deque-double ended queue.
import java.util.LinkedList;
import java.util.Deque;
public class P8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<String>dq=new LinkedList<String>();
		dq.add("usopp");
		dq.addFirst("robin");
		dq.addLast("franky");
		dq.push("chopper");
		System.out.println(dq);
		dq.pop();
		System.out.println("..............................");
		System.out.println(dq);
		System.out.println("..............................");
		dq.pollFirst();
		System.out.println(dq);
		dq.pollLast();
		System.out.println(dq);
	}
}
