package collection;
//hashmap example
import java.util.HashMap;
public class P12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String>m=new HashMap<Integer,String>();
		m.put(1,"gaara");
		m.put(2, "zoro");
		m.put(3, "minato");
		m.put(4, "lelouch");
		m.put(5,"light yagami");
		System.out.println(m);
		System.out.println(m.get(4));

	}

}
