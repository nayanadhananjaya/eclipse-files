package collection;
import java.util.Scanner;
import java.util.LinkedList;
public class P4 {
	private String name;
	private String address;
	private double gpa;
	static LinkedList<P4>al=new LinkedList<P4>();
	static Scanner sc=new Scanner(System.in);
	
	public P4(String name,String address,double Gpa) {
		super();
		this.name=name;
		this.address=address;
		gpa=Gpa;
	}
	public String getName() {
		return this.name;
	}
	public String getAddress() {
		return this.address;
	}
	public double getGPA() {
		return this.gpa;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<2;i++) {
			System.out.println("Enter student name");
			String name=sc.next();
			System.out.println("Enter student address");
			String address=sc.next();
			System.out.println("Enter student GPA");
			double gpa=sc.nextDouble();
			al.addLast(new P4(name, address, gpa));
		}
		System.out.println(al);

	}
	public String toString() {
		return "P4[name="+name+",address=" +address+",gpa=" +gpa+" ]";
	}

}
