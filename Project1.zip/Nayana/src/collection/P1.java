package collection;
//collection example

import java.util.ArrayList;
import java.util.Iterator;
public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(10);
		al.add(30);
		al.add(18);
		al.add(null);
		Iterator it=al.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
