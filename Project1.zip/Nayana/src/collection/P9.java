package collection;
//Arrayqueue example
import java.util.ArrayDeque;
import java.util.Deque;
public class P9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<Integer>dq=new ArrayDeque<Integer>();
		dq.add(10);
		dq.add(20);
		dq.add(50);
		System.out.println(dq);
		dq.clear();
		System.out.println(dq);
	}
}
