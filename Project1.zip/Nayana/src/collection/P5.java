package collection;
import java.util.Vector;
import java.util.Iterator;
public class P5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String>obj=new Vector<String>();
		obj.add("luffy");
		obj.add("zoro");
		obj.add("sanji");
		obj.add("nami");
		Iterator it=obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
