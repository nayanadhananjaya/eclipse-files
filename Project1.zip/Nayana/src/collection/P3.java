package collection;
import java.util.LinkedList;
import java.util.Iterator;
public class P3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer>obj=new LinkedList<Integer>();
		obj.add(10);
		obj.add(20);
		obj.add(50);
		obj.add(40);
		Iterator it=obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
