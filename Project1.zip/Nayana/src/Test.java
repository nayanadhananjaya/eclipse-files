//to add two numbers
public class Test {
	public static void main(String args[]) {
		int num1=10;
		int num2=20;
		int res;
		res= num1+ num2;
		System.out.println("Sum of two numbers is: " +res);
		}

}
