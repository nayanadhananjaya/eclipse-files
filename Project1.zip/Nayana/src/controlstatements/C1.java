package controlstatements;

import java.util.Scanner;

public class C1 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		if(age<18)
			System.out.println("Not eligible!!!");
		else
			System.out.println("You are eligible");
		sc.close();
	}
	

}
