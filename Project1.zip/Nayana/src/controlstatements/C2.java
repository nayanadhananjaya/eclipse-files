package controlstatements;

import java.util.Scanner;

public class C2 {
	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter percentage:");
		int percent=sc.nextInt();
		
		if(percent>=85&&percent<100)
			System.out.println("Distinction");
		else if(percent>=60&&percent<85)
			System.out.println("First class");
		else if(percent>=35&&percent<60)
			System.out.println("second class");
		else if(percent>=0&&percent<35)
			System.out.println("Fail");
		else
			System.out.println("Enter percentage between 0 and 100");
	}

}
