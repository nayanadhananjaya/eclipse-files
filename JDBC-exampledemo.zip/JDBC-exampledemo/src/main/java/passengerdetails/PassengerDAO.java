package passengerdetails;
import org.springframework.jdbc.core.JdbcTemplate;


public class PassengerDAO {
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private JdbcTemplate jdbcTemplate;
	public int insertUser(Passenger pass) {
		String query="Insert into passenger values('"+pass.getName()+"','"+pass.getAge()+"','"+pass.getGender()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateUser(Passenger pass) {
		String query="Update passenger set age="+pass.getAge()+",gender= "+pass.getGender()+ "where name=" +pass.getName();
		return jdbcTemplate.update(query);
	}
	public int deleteUser(Passenger pass) {
		String query="Delete from passenger where age="+pass.getAge();
		return jdbcTemplate.update(query);
	}
	

	

}
