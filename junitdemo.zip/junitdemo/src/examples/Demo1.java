package examples;
class Calculation{
	public static int addition(int x,int y) {
		return x+y;
	}
	public static int subtraction(int x,int y) {
		return x-y;
	}
}

public class Demo1 extends Calculation{

	public static void main(String[] args) {
		Calculation obj=new Calculation();
		System.out.println("Sum of two numbers is :"+obj.addition(20, 20));
		System.out.println("Difference of two numbers is:"+ obj.subtraction(20, 10));
	}
}
