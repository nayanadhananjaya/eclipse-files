import java.sql.*;
public class TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb1","root","admin");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into contacts values (104,'nami','New york','USA')");
			System.out.println("Record inserted successfully");
			System.out.println("......................................");
			ResultSet rs=stmt.executeQuery("select * from contacts");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+ " "+rs.getString(2)+ " "+rs.getString(3));
			}
		
		}catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
