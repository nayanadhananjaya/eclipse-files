package traincasestudy;
public class Train {
	private int trainNo;
	private String trainName;
	private String source;
	private String Destination;
	private double ticketPrice;
	public Train() {
		
	}
	public Train(int tno,String tname,String src,String dest,double tprice) {
		this.setTrainNo(tno);
		this.setTrainName(tname);
		this.setSource(src);
		this.setDestination(dest);
		this.setTicketPrice(tprice);
	}
	public void setTrainNo(int tno) {
		this.trainNo=tno;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
}

