package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.bean.User;
import com.example.dao.UserDAO;

@Controller
public class UserController {
	@Autowired
	UserDAO dao;
	@RequestMapping("/userform")
	public String showform(Model model) {
		model.addAttribute("command",new User());
		return "userform";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String save(@ModelAttribute("user")User user) {
		dao.insertUser(user);
		return "redirect:/viewuser";//redirects to view user request mapping
	}
	@RequestMapping("/viewuser")
	public String viewuser(Model model) {
		List<User> user=dao.getUser();
		model.addAttribute("list",user);
		return "viewuser";
	}
	
	@RequestMapping("/edituser/{id}")
	public String edit(@PathVariable int id,Model model) {
		User user=dao.getUserById(id);
		model.addAttribute("command",user);
		return "usereditform";
	}
	@RequestMapping(value="/editsave",method=RequestMethod.POST)
	public String editsave(@ModelAttribute("user")User user){
		dao.updateUser(user);
		return "redirect:/viewuser";
	}
	@RequestMapping(value="/deleteuser/{id}",method=RequestMethod.GET)
	public String delete(@PathVariable int id) {
		dao.deleteUser(id);
		return "redirect:/viewuser";
	}

}
