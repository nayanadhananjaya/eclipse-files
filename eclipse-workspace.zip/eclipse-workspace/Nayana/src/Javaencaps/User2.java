package Javaencaps;
//encapsulation example
public class User2 {
	public static void main(String[] args) {
		User u1=new User();
		u1.setUserName("Nayana");
		u1.setPassword("qwerty");
		
		User u2=new User();
		u2.setUserName("Luffy");
		u2.setPassword("poiuyt");
		
		System.out.println(u1.getUserName() +" "+u1.getPassword());
		System.out.println(u2.getUserName() +" "+u2.getPassword());
		
		User3 u3=new User3();
		u3.setProductid(18);
		u3.setProductname("Laptop");
		u3.setProductprice(12233);
		
		System.out.println(u3.getProductid()+" "+u3.getProductname()+" "+u3.getProductprice());
	}

}
