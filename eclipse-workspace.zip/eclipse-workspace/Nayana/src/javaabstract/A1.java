package javaabstract;
//abstract example
abstract class A{
	int num=40;
	void display() {
		System.out.println(num);
	}
	abstract void calculate();
}
public class A1 extends A{
	void calculate() {
		System.out.println("message from calculator");
	}
	public static void main(String[]  args) {
		A1 obj=new A1();
		obj.calculate();
		obj.display();
	}

}
