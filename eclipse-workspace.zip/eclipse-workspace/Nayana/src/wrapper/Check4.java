package wrapper;
import java.util.ArrayList;
public class Check4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al= new ArrayList<String>();
		al.add("luffy");
		al.add("zoro");
		al.add("sanji");
	//	al.add(10);    //int not possible
		System.out.println(al.get(0));
	}
}
