package javaarray;
//array example
public class A2 {
	public static void main(String[] args) {
		int arr[]= {6,3,4};
		for(int i: arr) {
			System.out.println(i);
		}
	}

}
