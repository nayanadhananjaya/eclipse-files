package javaexception;

public class test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=20;
		String msg=null;
		try {
			System.out.println(msg.length());
			System.out.println(num/0);
		}catch(NullPointerException e) {
			System.out.println("I am null");
			System.out.println(e);	
		}catch(ArithmeticException e) {
			System.out.println(num/(0+1));
		}
	}
}
