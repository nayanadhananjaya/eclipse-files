package javaexception;
//throw example
public class Test8 {
	static boolean checknumber(int n) {
		if(n==0) {
			throw new ArithmeticException("Divide by zero error!!");
		}else {
			return true;
		}
	}
	public static void main(String[] args) {
		int num1=100;
		int num2=200;
		int result;
		System.out.println(1);
		try {
			if(checknumber(num2)) {
				result=num1/num2;
				System.out.println("The result is " +result);
			}
		}catch(Exception e) {
			System.out.println("from catch inside main "+e.getMessage());
		}
		System.out.println(2);
	}

}
