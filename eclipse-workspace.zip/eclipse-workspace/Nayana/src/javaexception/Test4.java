package javaexception;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=20;
		String msg=null;
		try {
			System.out.println(num/0);
			System.out.println(msg.length());
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
