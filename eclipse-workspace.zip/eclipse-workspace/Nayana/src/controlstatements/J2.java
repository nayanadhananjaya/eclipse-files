package controlstatements;
//multiplication example
public class J2 {
	public static void main(String args[]) {
		int num=5;
		for(int i=1;i<=10;i++) {
			System.out.println(num+ "*" +i+ "=" +num*i);
		}
	}

}
