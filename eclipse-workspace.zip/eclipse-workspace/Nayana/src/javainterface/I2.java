package javainterface;
interface Add{
	void addition(int x,int y);
}

public class I2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//annonymus inner class
		Add obj=new Add(){
		public void addition(int x, int y) {
			int res;
			res=x+y;
			System.out.println("Sum is " +res);
		}

	    };
	obj.addition(40,40);
    }
}
