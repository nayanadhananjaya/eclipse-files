package javainterface;

interface test1{
	void display();
}
interface test2 extends test1{
	void calculate();
}

public class I1 implements  test2  {
	public void display() {
		System.out.println("msg grom display");
	}
	public void calculate() {
		System.out.println("msg grom calculate");
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I1 obj=new I1();
		obj.display();
		obj.calculate();

	}

}
