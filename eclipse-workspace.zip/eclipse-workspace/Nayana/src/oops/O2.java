package oops;

class person{
	int id;
	String name;
	
	person(){     //contructor
		id=101;
		name="Nayana";
	}
	void display() {
		System.out.println( " Name and id is: " +name+ " " +id);
	}
}

public class O2 {
	public static void main(String[] args) {
		person obj=new person();
		obj.display();	
	}
}
