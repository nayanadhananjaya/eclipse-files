package oops;
//Parametarized contructor example
class Hotel{
	int years;
	String name;
	String place;
	
	Hotel(){
		System.out.println("Default constructor");
	}
	Hotel(int years,String name,String place){
		this.years=years;
		this.name=name;
		this.place=place;
	}
	void display() {
		System.out.println(years + " " +name+ " " +place);
	}
}
public class O3 {
	public static void main(String[] args) {
		Hotel h1=new Hotel(3,"Le Meridian","Banglore");
		h1.display();
		
		Hotel h2=new Hotel(5,"Ashoka Hotel","Hassan");
		h2.display();
	}

}
