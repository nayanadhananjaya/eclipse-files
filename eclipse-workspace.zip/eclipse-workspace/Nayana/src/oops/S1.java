package oops;
// use of super example
class Bike{
	int speed=100;
	Bike(){
		System.out.println("Bike is running at speed " +speed+ "km/h");
	}
	void display() {
		System.out.println("msg from display");
	}
}
class Honda extends Bike{
	int speed=20;
	Honda(){
		super();
		System.out.println("bike honds is good!!");
	}
	void show() {
		System.out.println(super.speed);
		System.out.println(this.speed);
		super.display();
	}
}
public class S1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Honda obj=new Honda();
		obj.show();
	}
}
