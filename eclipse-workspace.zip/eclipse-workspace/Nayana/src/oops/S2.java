package oops;
//static example
class counter{
	static int count=0;
	counter(){
		count++;
		System.out.println(count);
	}
}

public class S2 {
	public static void main(String[] args) {
		counter obj=new counter();
		counter obj1=new counter();
		counter obj2=new counter();
		
	}
}
