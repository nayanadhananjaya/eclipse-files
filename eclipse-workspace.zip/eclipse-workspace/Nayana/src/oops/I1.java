package oops;
//Inheritance example

class A{
	int number1=200;
}
class C extends A{
	int number3=400;
}
class B extends C{
	int number2=100;
	int res;
	void display() {
		System.out.println(number1);
		}
	void addition() {
		res=number1+number2+number3;
		System.out.println("Sum of numbers is: "+res);
		
	}
}
public class I1 {
	public static void main(String[] args) {
		B b=new B();
		b.display();
		b.addition();
	}
	

}
