package collection;
//only unique values get executed
import java.util.HashSet;
import java.util.Set;
public class P10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String>s=new HashSet<String>();
		s.add("luffy");
		s.add("zoro");
		s.add("nami");
		s.add("sanji");
		s.add("zoro");
		System.out.println(s);
	}
}
