package collection;
//union and intersection and difference example
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
public class P11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> s1=new HashSet<Integer>();
		s1.addAll(Arrays.asList(new Integer[] {1,0,3,23,78,4,5,6}));
		Set<Integer> s2=new HashSet<Integer>();
		s2.addAll(Arrays.asList(new Integer[]{2,7,8,5,78,90,23,4,9,1}));
		
		Set<Integer>union=new HashSet<Integer>(s1);
		union.addAll(s2);
		System.out.println(union);
		
		Set<Integer>intersection=new HashSet<Integer>(s1);
		intersection.retainAll(s2);
		System.out.println(intersection);
		Set<Integer>difference=new HashSet<Integer>(s1);
		difference.removeAll(s2);
		System.out.println(difference);
	}
}
