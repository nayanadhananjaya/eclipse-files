package collection;
//priority queue example
import java.util.PriorityQueue;
import java.util.Iterator;
public class P7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<String>pq=new PriorityQueue<String>();
		pq.add("eren");
		pq.add("mikasa");
		pq.add("levi");
		pq.add("armin");
		Iterator it=pq.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("............................................");
		pq.remove();
		//pq.poll();
		Iterator it1=pq.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
	}
}
