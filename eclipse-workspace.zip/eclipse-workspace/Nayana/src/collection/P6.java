package collection;
//stack example
import java.util.Stack;
import java.util.Iterator;
public class P6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String>obj=new Stack<String>();
		obj.push("naruto");
		obj.push("sasuke");
		obj.push("kakashi");
		Iterator it=obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("............................................");
		obj.pop();
		Iterator it1=obj.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
	}
}
