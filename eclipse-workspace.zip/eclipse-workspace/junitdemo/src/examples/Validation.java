package examples;
import java.util.Scanner;
class Validate {
	public static String validate(String uname,String pwd) {
		if(uname.equals("admin")&&pwd.equals("admin123"))
			return "valid details";
		else if(uname.equals(" ")&& pwd.equals("admin123"))
			return "Blank username";
		else if(uname.equals("admin")&& pwd.equals(" "))
			return "Blank password";
		else if(uname.equals(" ")&& pwd.equals(" "))
			return "Blank username and password";
		else
			return "Invalid details";
	}
}	
public class Validation extends Validate{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username");
		String username=sc.next();
		System.out.println("Enter password");
		String password=sc.next();
		System.out.println(validate(username,password));

	}
}
