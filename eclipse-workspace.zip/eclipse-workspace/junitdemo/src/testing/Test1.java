package testing;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import examples.*;
import org.junit.Test;

public class Test1 {
      @Before
      public void beforeTest() {
    	  System.out.println("Executed before test");
      }
      @Test
	public void addition() {
		System.out.println("Actual test");
		assertEquals(60,Demo1.addition(30,30));
		//assertEquals(40,Demo1.addition(30,30));
		assertEquals(40,Demo1.subtraction(120, 80));
	}
      @After
	public void afterTest() {
		System.out.println("Executed after test");
	}

}
