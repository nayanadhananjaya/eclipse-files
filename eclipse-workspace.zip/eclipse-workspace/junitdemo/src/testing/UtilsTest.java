package testing;


import static org.junit.Assert.assertEquals;
import org.junit.Test;
import examples.*;
public class UtilsTest {
	@Test
	public void testvalidate() {
		//assertEquals("valid details",Validation.validate("admin","admin123"));
		//assertEquals("Blank username",Validation.validate(" ","admin123"));
		//assertEquals("Blank password",Validation.validate("admin"," "));
		//assertEquals("Blank username and password",Validation.validate(" "," "));
		assertEquals("Invalid details",Validation.validate("admin123","admin"));
	}

}
