package com.example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.bean.User;


public class UserDAO {
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	private JdbcTemplate jdbcTemplate;
	
	
	public int insertUser(User user) {
		String query="insert into user values("+user.getId()+",'"+user.getEmail()+"','"+user.getPassword()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateUser(User user) {
		String query="update user set email="+user.getEmail()+",password= "+user.getPassword()+ "where id=" +user.getId();
		return jdbcTemplate.update(query);
	}
	public int deleteUser(int id) {
		String query="delete from user where id=" +id+"";
		return jdbcTemplate.update(query);
	}
	public User getUserById(int id) {
		String query="select * from userwhere id=?";
		return jdbcTemplate.queryForObject(query, new Object[] {id},new BeanPropertyRowMapper<User>(User.class));
	}
	public List<User> getUser(){
		return jdbcTemplate.query("select * from user",new RowMapper<User>() {
			public User mapRow(ResultSet rs,int row)throws SQLException{
				User user=new User();
				user.setId(rs.getInt(1));
				user.setEmail(rs.getString(2));
				user.setPassword(rs.getString(3));
				return user;
			}
		});
	}

}


