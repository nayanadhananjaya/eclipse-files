package com.example.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\user51\\Downloads\\chromedriver_win32");
		WebDriver test=new ChromeDriver();
		test.get("https://www.google.com/");
		test.findElement(By.xpath("//input[@id='pass']")).sendKeys("123");
		
	}

}
