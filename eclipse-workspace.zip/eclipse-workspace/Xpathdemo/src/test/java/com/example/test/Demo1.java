package com.example.test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {
public static void main(String[] args) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\user51\\Downloads\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.facebook.com/");
			driver.findElement(By.id("email")).sendKeys("sample@gmail.com");
			driver.findElement(By.id("pass")).sendKeys("sample123");
			driver.findElement(By.name("login")).click();
}

}

