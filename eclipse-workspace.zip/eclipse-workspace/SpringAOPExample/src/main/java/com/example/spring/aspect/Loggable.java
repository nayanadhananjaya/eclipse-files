package com.example.spring.aspect;

public @interface Loggable {

}
