package demo1;



public class Passenger {
	private String name;
	private String age;
	private String gender;
	
	public Passenger() {
		System.out.println("Default constructor invoked!!!");
	}
	
	public Passenger(String name,String age,String gender) {
		this.name=name;
		this.age=age;
		this.gender=gender;
	}
	void display() {
		System.out.println("Passenger details :" +name+ "  \n"+age+"  \n"+gender);
	}

}
