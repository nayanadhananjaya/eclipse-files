/*package calculation;


class calculation {
		public static int addition(int x,int y) {
			return x+y;
		}

}
public class Calculation extends calculation{

	public static void main(String[] args) {
		Calculation obj=new Calculation();
		System.out.println("Sum of two numbers is :"+obj.addition(20, 20));
		//System.out.println("Difference of two numbers is:"+ obj.subtraction(20, 10));
	}
}*/

