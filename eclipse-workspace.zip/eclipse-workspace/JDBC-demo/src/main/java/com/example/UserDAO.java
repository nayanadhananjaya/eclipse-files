package com.example;

import org.springframework.jdbc.core.JdbcTemplate;

public class UserDAO {
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	private JdbcTemplate jdbcTemplate;
	
	
	public int insertUser(User user) {
		String query="Insert into user values("+user.getId()+",'"+user.getEmail()+"','"+user.getPassword()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateUser(User user) {
		String query="Update user set email="+user.getEmail()+",password= "+user.getPassword()+ "where id=" +user.getId();
		return jdbcTemplate.update(query);
	}
	public int deleteUser(User user) {
		String query="Delete from user where id="+user.getId();
		return jdbcTemplate.update(query);
	}

}
